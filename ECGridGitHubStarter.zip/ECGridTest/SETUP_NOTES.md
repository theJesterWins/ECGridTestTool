# Setup notes

Before publishing, change these placeholders in `ECGridOsSafeWorkbench.csproj`:

- `YOUR_GITHUB_USERNAME`
- package name, author, company, description, and version if desired

## Manual GitHub Packages publish

```bash
dotnet pack .\ECGridOsSafeWorkbench.csproj -c Release

dotnet nuget add source --username YOUR_GITHUB_USERNAME --password YOUR_GITHUB_PAT --store-password-in-clear-text --name github "https://nuget.pkg.github.com/YOUR_GITHUB_USERNAME/index.json"

dotnet nuget push ".\bin\Release\ECGridOsSafeWorkbench.1.0.0.nupkg" --source github --api-key YOUR_GITHUB_PAT
```

## Recommended for desktop app downloads

For people who just want to run the app, use a GitHub Release instead of making them install a NuGet package.

```bash
dotnet publish .\ECGridOsSafeWorkbench.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```
