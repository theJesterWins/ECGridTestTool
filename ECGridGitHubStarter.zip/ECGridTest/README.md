# ECGridOS Safe Workbench

Windows Forms workbench for **ECGridOS safe send and receive testing**.

## What it does

- Connects to an ECGrid service URL with a SessionID / API key
- Checks the inbox and previews parcel metadata
- Downloads selected parcels with confirmation steps
- Supports restore-to-inbox for receive-side testing
- Preserves original bytes when payloads have not been edited
- Warns before file preview and cross-mailbox download scenarios

## Notes

- Target framework: `net8.0-windows`
- UI technology: Windows Forms
- This repository can be published to **GitHub Packages** as a NuGet package
- For end-user downloads, a **GitHub Release** with published binaries is usually the friendlier option

## Local run

```bash
dotnet run --project .\ECGridOsSafeWorkbench.csproj
```

## Package / publish

- NuGet package: `dotnet pack -c Release`
- Windows release build: `dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true`
